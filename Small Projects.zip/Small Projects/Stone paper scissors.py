import random

scissors = r'''
   _       ,/'
  (_).  ,/'
   _  ::
  (_)'  `\.
           `\.
'''

paper = r'''
  .--""--.___.._
 (  <__>  )     `-.
 |`--..--'|      <|
 |       :|       /
 |       :|--""-./
 `.__  __;'       
'''

rock = r'''
       ,--.--._
------" _, \___)
        / _/____)
        \//(____)
------\     (__)
       `-----"
'''

options = [scissors, paper, rock]
opponent = random.choice(options)



player = int(input('Type 0 for "scissors", 1 for "paper", 2 for "rock" '))
if player == 0:
    print(options[0])
elif player == 1:
    print(options[1])
else:
    print(options[2])

print(f"Computer chose:\n{opponent}")
if player == 0 and opponent == options[1]:
    print("You won")
elif player == 1 and opponent == options[2]:
    print("You won")
elif player == 2 and opponent == options[0]:
    print("You won")
elif player == 0 and opponent == options[2]:
    print("You lost")
elif player == 1 and opponent == options[0]:
    print("You lost")
elif player == 2 and opponent == options[1]:
    print("You lost")
else:
    print("Play again")