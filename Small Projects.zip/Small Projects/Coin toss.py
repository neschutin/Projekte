import random

coin_toss = random.randint(1, 2)

if coin_toss == 1:
    print("Heads")
else:
    print("Tails")