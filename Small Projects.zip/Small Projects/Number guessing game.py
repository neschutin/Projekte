import random

# This function lets the user guess and checks if the input is correct
def main():
    random_number = random.randint(1, 10)
    attempts = 0
    while True:
        guess = int(input("Guess the random number between 1 and 10: "))
        attempts += 1
        if guess == random_number:
            print(f"Congrats, you got it! You needed {attempts} attempts")
            break
        elif guess >= random_number:
            print("You guessed too high.")
        else:
            print("You guessed too low.")

main()