import os


# Functions for adding, subtracting, multiplying and dividing
def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if a or b == 0:
        return "Error: You can't divide by 0"
    return a / b

# Takes the user input, splits the input and turns them into integers
def number_input():
    number_in = input("Type in 2 numbers ")
    numbers = number_in.split()
    return int(numbers[0]), int(numbers[1])

# Asks the user if he wants to calculate something else or not
def keep_calculating():
    user_input = input("Calculate something else? Type 'yes' or 'no'\n")
    if user_input.upper() == "YES":
        return "YES"
    elif user_input.upper() == "NO":
        return "NO"
    else:
        return "Error: Try again"

# Error handling if the user input isn't yes or no
def keep_calculating_error_input():
    error = True
    global running

    while error:
        error_input = input("Error: You can only type 'yes' or 'no' ")
        if error_input.upper() == "YES":
            break
        elif error_input.upper() == "NO":
            print("Goodbye thanks for using the calculator")
            error = False
            running = False
        else:
            pass

running = True
while running:
    choice = input("What do you want to do?\n1. add\n2. subtract\n3. multiply\n4. divide\n")
    os.system("clear")
    if choice == "1":
        number1, number2 = number_input()
        print(number1 + number2)
        answer = keep_calculating()
        if answer == "YES":
            pass
        elif answer == "NO":
            os.system("clear")
            print("Goodbye thanks for using the calculator")
            break
        else:
            keep_calculating_error_input()

    elif choice == "2":
        number1, number2 = number_input()
        print(number1 - number2)
        answer = keep_calculating()
        if answer == "YES":
            pass
        elif answer == "NO":
            os.system("clear")
            print("Goodbye thanks for using the calculator")
            break
        else:
            keep_calculating_error_input()
    elif choice == "3":
        number1, number2 = number_input()
        print(number1 * number2)
        answer = keep_calculating()
        if answer == "YES":
            pass
        elif answer == "NO":
            os.system("clear")
            print("Goodbye thanks for using the calculator")
            break
        else:
            keep_calculating_error_input()
    elif choice == "4":
        number1, number2 = number_input()
        print(number1 / number2)
        answer = keep_calculating()
        if answer == "YES":
            pass
        elif answer == "NO":
            os.system("clear")
            print("Goodbye thanks for using the calculator")
            break
        else:
            keep_calculating_error_input()
    else:
        print("Error: Try again")
        pass