weight = int(input("Your weight\n"))
lbs_or_kg = input("(L)bs or (k)g?\n")

if lbs_or_kg.upper() == "L":
    converted = weight * 0.45
    print(f"You weigh {converted} kg")
else:
    converted = weight / 0.45
    print(f"You weigh {converted} pounds")

