from random import choice, randint
import pygame
from sys import exit

pygame.init()
width = 610
height = 800
x_middle = width / 2
window = pygame.display.set_mode((width, height))
pygame.display.set_caption("Space War")
pygame.display.set_icon(pygame.image.load("Graphics/Sprites/Player Ship/player_ship.png"))
game_state = "intro"
score = 0
hp = 5

clock = pygame.time.Clock()
fps = 60

# Player and Enemies classes
class PlayerShip(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.space_ship = pygame.transform.scale(
            pygame.image.load("Graphics/Sprites/Player Ship/player_ship.png").convert_alpha(), (75, 75))
        self.image = self.space_ship
        self.rect = self.image.get_rect(center = (x_middle, 700))
        self.hp = 5

    def player_input(self):
        pressed_key = pygame.key.get_pressed()

        if pressed_key[pygame.K_d] and self.rect.right < 610:
            self.rect.x += 6
        elif pressed_key[pygame.K_a] and self.rect.left > 0:
            self.rect.x -= 6
        elif pressed_key[pygame.K_SPACE]:
            pass

    def update(self):
        self.player_input()

class Enemies(pygame.sprite.Sprite):
    def __init__(self, type):
        super().__init__()
        self.type = type
        if type == "red":
            enemy_red = pygame.transform.scale(
                pygame.image.load("Graphics/Sprites/Enemies/enemy_red.png").convert_alpha(), (75, 50)
            )
            self.enemy = enemy_red
        if type == "gold":
            enemy_gold = pygame.transform.scale(
                pygame.image.load("Graphics/Sprites/Enemies/enemy_gold.png").convert_alpha(), (75, 50)
            )
            self.enemy = enemy_gold
        if type == "blue":
            enemy_blue = pygame.transform.scale(
                pygame.image.load("Graphics/Sprites/Enemies/enemy_blue.png").convert_alpha(), (75, 50)
            )
            self.enemy = enemy_blue
        self.image = self.enemy
        self.rect = self.image.get_rect(center = (randint(40, 570), -50))

    def enemy_movement(self):
        self.rect.y += 5

    def disappear(self):
        global score

        if self.rect.y >= 840:
            self.kill()
            score += 1

    def update(self):
        self.enemy_movement()
        self.disappear()


def display_score():
    score_surface = font.render(f"Score: {score}", False, "pink")
    score_rectangle = score_surface.get_rect(center = (x_middle, 75))
    window.blit(score_surface, score_rectangle)

def display_controls():
    left_control_surface = small_font.render("A - Move left", False, "pink")
    left_control_rectangle = left_control_surface.get_rect(topleft = (10, 25))

    right_control_surface = small_font.render("D - Move right", False, "pink")
    right_control_rectangle = right_control_surface.get_rect(topleft = (10, 60))

    shoot_control_surface = small_font.render("SPACE - Shoot", False, "pink")
    shoot_control_rectangle = shoot_control_surface.get_rect(topleft = (10, 95))

    window.blit(left_control_surface, left_control_rectangle)
    window.blit(right_control_surface, right_control_rectangle)
    window.blit(shoot_control_surface, shoot_control_rectangle)

def collision():
    global hp

    for enemy_sprite in pygame.sprite.spritecollide(player.sprite, enemy, True):
        if enemy_sprite.type == "gold":
            hp -= 4
            pygame.mixer.Sound.play(damage_sound)
        else:
            hp -= 1
            pygame.mixer.Sound.play(damage_sound)


def display_hp():
    player_ship = player.sprite
    hp_font = pygame.font.Font("Graphics/SpaceMadness.ttf", 60)
    hp_surface = hp_font.render(f"HP: {hp}", False, "lime")
    if player_ship:
        hp_x = player_ship.rect.centerx
        hp_y = player_ship.rect.bottom + 20
    hp_rectangle = hp_surface.get_rect(center = (hp_x, hp_y))
    if hp_rectangle.right >= width:
        hp_rectangle.right = width
    if hp_rectangle.left <= 0:
        hp_rectangle.left = 0
    if hp == 2:
        hp_surface = hp_font.render(f"HP: {hp}", False, "yellow")
    if hp == 1:
        hp_surface = hp_font.render(f"HP: {hp}", False, "red")
    window.blit(hp_surface, hp_rectangle)


def restart_quit():
    global game_state
    global hp
    global score

    mouse_buttons = pygame.mouse.get_pressed(3)
    mouse_position = pygame.mouse.get_pos()

    restart_surface = font.render("RESTART", False, "pink")
    restart_rectangle = restart_surface.get_rect(center=(x_middle, 350))

    quit_surface = font.render("QUIT", False, "pink")
    quit_rectangle = quit_surface.get_rect(center = (x_middle, 450))

    window.blit(restart_surface, restart_rectangle)
    if mouse_buttons[0]:
        if restart_rectangle.collidepoint(mouse_position):
            game_state = "gameplay"
            hp = 5
            score = 0
            pygame.mixer.Sound.play(selection_sound)

    window.blit(quit_surface, quit_rectangle)
    if mouse_buttons[0]:
        if quit_rectangle.collidepoint(mouse_position):
            pygame.quit()
            exit()


player = pygame.sprite.GroupSingle()
player.add(PlayerShip())

enemy = pygame.sprite.Group()
enemy_timer = pygame.USEREVENT + 1
pygame.time.set_timer(enemy_timer, 500)


background_image = pygame.image.load("Graphics/Background/space_background.png").convert()
blurred_image = pygame.image.load("Graphics/Background/blurred_background.png").convert()
font = pygame.font.Font("Graphics/SpaceMadness.ttf", 55)
small_font = pygame.font.Font("Graphics/SpaceMadness.ttf", 45)

selection_sound = pygame.mixer.Sound("Sounds/menu select.wav")
pygame.mixer.Sound.set_volume(selection_sound, 0.2)
damage_sound = pygame.mixer.Sound("Sounds/damage.wav")
pygame.mixer.Sound.set_volume(damage_sound, 0.2)
music = pygame.mixer.Sound("Sounds/music.ogg")
pygame.mixer.Sound.set_volume(music, 0.1)
music.play(-1)


running = True
while running:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if event.type == enemy_timer:
            enemy.add(Enemies(choice(["red", "red", "red", "blue", "blue", "blue", "gold"])))

    # Intro state
    if game_state == "intro":
        window.blit(blurred_image, (0,0))
        display_controls()

        pressed_key = pygame.key.get_pressed()
        if pressed_key[pygame.K_SPACE]:
            game_state = "gameplay"
        enemy.empty()

    # Main state
    if game_state == "gameplay":
        window.blit(background_image, (0,0))
        player.draw(window)
        player.update()
        enemy.draw(window)
        enemy.update()
        display_hp()
        collision()
        display_score()

        if hp <= 0:
            game_state = "game over"

    if game_state == "game over":
        window.blit(blurred_image, (0,0))
        enemy.empty()
        end_score = small_font.render(f"Your score was: {score}", False, "pink")
        end_score_rectangle = end_score.get_rect(center = (x_middle, 100))
        window.blit(end_score, end_score_rectangle)
        restart_quit()

    pygame.display.update()
    clock.tick(fps)
